<?php

function verify_name($str){

    if(preg_match("/[a-zA-Z]{2,30}/",$str)){
        return true ;
    }else{
        return false ;
    }

}

function verify_email($email){
    if(filter_var($email,FILTER_VALIDATE_EMAIL)){
        return true ;
    }else{
        return false ;
    }
}











?>