<?php

class shop{
    public $id;
    public $nb ;
    
    function __cotruct($id,$nb) {
        
        $this->nb=$nb ;

    }
    
    function get_total(){
        return $nb ;
    }
    
}


?>