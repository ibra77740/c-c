<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);





?>

<!DOCTYPE HTML>

<html>
	<head>
		<title>Acceuil</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<style>
			.logoname{
				
				width: 500px;
				
			}
			.logox{
				margin-top: 15px;
				width: 60px;
			}
			.hoverimage{
				background-color: brown;
	 		 }
			.catx{
				width: 400px;
				border-radius: 50%;
				position: relative;
				right: -100px;
				transition: width .5s;
				cursor: pointer;
			}
			.catx:hover{
				width: 500px;
			}

			.leftcatx{
				width: 400px;
				border-radius: 50%;
				position: relative;
				left: -100px;
				transition: width .5s;
				cursor: pointer;
			}
			.leftcatx:hover{
				width: 500px;
			}
			
			
			.signupbut {

				display: inline-block;
                    outline: none;
                    cursor: pointer;
                    border-radius: 3px;
                    
                    line-height: 16px;
                    padding: 2px 16px;
                    height: 38px;
					margin: 3px;
                    min-width: 96px;
                    min-height: 38px;
					font-size: 20px;
					font-weight: 900;
                    border: none;
                    color: #fff;
                    background-color: rgb(88, 101, 242);
                    transition: background-color .17s ease,color .17s ease;
                   
                
			}
			.signinbut:hover {
                        background-color: rgb(71, 82, 196);
                    }
					.signinbut {

						display: inline-block;
							outline: none;
							cursor: pointer;
							border-radius: 3px;
							font-size: 20px;
							margin: 3px;
							font-weight: 900;
					

							line-height: 16px;
							padding: 2px 16px;
							height: 38px;
							min-width: 96px;
							min-height: 38px;
							border: none;
							color: #fff;
							background-color: rgb(0, 0, 0);
							transition: background-color .17s ease,color .17s ease;
						

						}
						.signinbut:hover {
								background-color: rgb(81, 81, 81);
							}
		</style>
	</head>
	<body class="is-preload">
		<div class="mynav ">
		<div class="rightnav ">
			<ul>
				<li id="home" class="selected">Acceul</li>
				<li id="products" >Produits</li>
				<li id="surdemande">sur demande</li>
			</ul>
		</div>
		<div class="searchcontainer ">
			<input type="text" class="searchinput" placeholder="rechercher...">
		</div>
		<div class="account pure-g">
			<?php 
				
				if(isset( $_SESSION['user'])){
					echo '<i class="fa-solid fa-bag-shopping card" id="panel"></i>';
					echo '<span class="username">';
					echo  $_SESSION['user']->nom." ". $_SESSION['user']->prenom ;
					echo '</span>';
					echo '<i class="fa-regular fa-user user"></i>';
				}else{
					echo '<button class="signupbut">s\'inscrire</button>';
					echo '<button class="signinbut">se connecter</button>';
				}



			?>


			
			
		</div>
		</div>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				
					

				<!-- Menu -->
					

				<!-- Banner -->
					<section id="banner">
						<div class="inner">
							<div class="logo"><span class="icon"><img class="logox" src="logo.png" alt=""></span></div>
							<h2><img class="logoname" src="logoname.png" alt=""></h2>
							<p>Nous considérons l'artisanat comme une des formes exemplaires de l'activité humaine.</p>
						</div>
					</section>

				<!-- Wrapper -->
					<section id="wrapper">

						<!-- One -->
							<section id="one" class="wrapper spotlight style1">
								<div class="inner">
									<img class="catx" src="images/pic01.jpg" alt="">
									<div class="content">
										<h2 class="major">Magna arcu feugiat</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>

						<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="images/pic01.jpg" alt="">									<div class="content">
										<h2 class="major">Tempus adipiscing</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>

						<!-- Three -->
							<section id="three" class="wrapper spotlight style3">
								<div class="inner">
									<img class="catx" src="images/pic01.jpg" alt="">
									<div class="content">
										<h2 class="major">Nullam dignissim</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>
							<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="images/pic01.jpg" alt="">
									<div class="content">
										<h2 class="major">Tempus adipiscing</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>

						<!-- Three -->
							<section id="three" class="wrapper spotlight style3">
								<div class="inner">
									<img class="catx" src="images/pic01.jpg" alt="">
									<div class="content">
										<h2 class="major">Nullam dignissim</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>
							<!-- Two -->
							<section id="two" class="wrapper alt spotlight style2">
								<div class="inner">
								<img class="leftcatx" src="images/pic01.jpg" alt="">
									<div class="content">
										<h2 class="major">Tempus adipiscing</h2>
										<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
										<a href="#" class="special">voir plus</a>
									</div>
								</div>
							</section>


						<!-- Four -->
							<section id="four" class="wrapper alt style1">
								<div class="inner">
									<h2 class="major">Vitae phasellus</h2>
									<p>Cras mattis ante fermentum, malesuada neque vitae, eleifend erat. Phasellus non pulvinar erat. Fusce tincidunt, nisl eget mattis egestas, purus ipsum consequat orci, sit amet lobortis lorem lacus in tellus. Sed ac elementum arcu. Quisque placerat auctor laoreet.</p>
									<section class="features">
										<article>
											<a href="#" class="image"><img src="images/pic04.jpg" alt="" /></a>
											<h3 class="major">Sed feugiat lorem</h3>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.</p>
											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="images/pic05.jpg" alt="" /></a>
											<h3 class="major">Nisl placerat</h3>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.</p>
											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="images/pic06.jpg" alt="" /></a>
											<h3 class="major">Ante fermentum</h3>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.</p>
											<a href="#" class="special">voir plus</a>
										</article>
										<article>
											<a href="#" class="image"><img src="images/pic07.jpg" alt="" /></a>
											<h3 class="major">Fusce consequat</h3>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.</p>
											<a href="#" class="special">voir plus</a>
										</article>
									</section>
									<ul class="actions">
										<li><a href="#" class="button">Browse All</a></li>
									</ul>
								</div>
							</section>

					</section>

				




					<footer>
								<div class="footer">
								<div class="row social">
								<a href="#"><i  class="fa-brands fa-facebook"></i></a>
								<a href="#"><i class="fa-brands fa-instagram"></i></a>
								<a href="#"><i class="fa-brands fa-youtube"></i></a>
								<a href="#"><i class="fa-brands fa-twitter"></i></a>
								</div>
								
								<div class="row links">
								<ul>
								<li><a href="#">Nous contacter</a></li>
								<li><a href="#">Our Services</a></li>
								<li><a href="#">Politique de confidentialité</a></li>
								<li><a href="#">termes et conditions</a></li>
								<li><a href="#">Career</a></li>
								</ul>
								</div>
								
								<div class="row">
								2023 || Designed By: master sid
								</div>
								</div>
								</footer>










					
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>