<?php

require "account_functions.php" ; 

		unset($_SESSION['mypanel'][$_GET['id']]);
        unset($_SESSION['mypanelnb'][$_GET['id']]);

        header("Location:http://localhost/roma/panel.php");
	





?>