<?php

session_start();

?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "account_functions.php" ;
$article = get_article_by_id($_GET['id']);




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>produit</title>
    <link rel="stylesheet" href="info.css">
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .signupbut {

display: inline-block;
    outline: none;
    cursor: pointer;
    border-radius: 3px;
    
    line-height: 16px;
    padding: 2px 16px;
    height: 38px;
    margin: 3px;
    min-width: 96px;
    min-height: 38px;
    font-size: 20px;
    font-weight: 500;
    border: none;
    color: #fff;
    background-color: rgb(88, 101, 242);
    transition: background-color .17s ease,color .17s ease;
   

}
.signinbut:hover {
        background-color: rgb(71, 82, 196);
    }
    .signinbut {

        display: inline-block;
            outline: none;
            cursor: pointer;
            border-radius: 3px;
            font-size: 20px;
            margin: 3px;
            font-weight: 500;
    

            line-height: 16px;
            padding: 2px 16px;
            height: 38px;
            min-width: 96px;
            min-height: 38px;
            border: none;
            color: #fff;
            background-color: rgb(0, 0, 0);
            transition: background-color .17s ease,color .17s ease;
        

        }
        .signinbut:hover {
                background-color: rgb(81, 81, 81);
            }
    </style>
</head>
<body>
    
    <div class="procontainer pure-g">
        
        <div class="proimg pure-u-1-2">
            
           <?php
                echo '<div class="imgdiv" style="background-image: url(\''.$article['imgArt'].'\');">';
                echo '';
                echo '</div>';
           ?>
           
        </div>
        <div class="pure-u-1-2">
            <div class="nav pure-g">
                <div class="pure-u-1-2">
                    <i class="fa-solid fa-arrow-left back"></i>
                </div>

                <div class="pure-u-1-2">
                    <div class="account pure-g">
                    <?php 
				
				if(isset( $_SESSION['user'])){
					echo '<i class="fa-solid fa-bag-shopping card" id="panel"></i>';
					echo '<span class="username">';
					echo  $_SESSION['user']->nom." ". $_SESSION['user']->prenom ;
					echo '</span>';
					echo '<i class="fa-regular fa-user user"></i>';
				}else{
					echo '<button class="signupbut">sign up</button>';
					echo '<button class="signinbut">Sign in</button>';
				}



			?>
                    </div>
                </div>
               
            </div>
            <div class="textdiv">
                <h2>
                    <?php
                        echo $article['nom'];
                    ?>
                </h2>
                
                <span class="mininfo">
                <?php
                        echo $article['date'];
                    ?>
                </span>
                
                <h2 class="price">
                <?php
                        echo $article['prix']." DH";
                    ?>
                </h2>
                <div class="proinfo">
                <?php
                        echo $article['desc'];
                    ?>                    
                </div>
                <div class="product-count">
                    <button class="button-count no-active" disabled>-</button>
                    <input id="nbpro" type="text" readonly class="number-product" value="1">
                    <button class="button-count">+</button>
                </div>
                <div class="but">
                    <?php


				
                        if(isset( $_SESSION['user'])){
                            
                            echo "<button id='addbutton' value=$article[id] class=\"addbutton\">";
                            echo 'add product';
                            echo '</button>';
                            
                        }else{
                            echo "<button id='signbutton' button value=$article[id] class=\"addbutton\">";
                            echo 'add product';
                            echo '</button>';
                            
                        }





                    ?>
                    <i class="fa-regular fa-heart like"></i>
                </div>
                
            </div>
            <div class="infofooter">
                <ul>
                    <li>a propos</li>
                    <li>contacter nous</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery.scrollex.min.js"></script>

    <script>
                    var num;

            $('.button-count:first-child').click(function(){
            num = parseInt($('input:text').val());
            if (num > 1) {
                $('input:text').val(num - 1);
            }
            if (num == 2) {
                $('.button-count:first-child').prop('disabled', true);
            }
            if (num == 10) {
                $('.button-count:last-child').prop('disabled', false);
            }
            });

            $('.button-count:last-child').click(function(){
            num = parseInt($('input:text').val());
            if (num < 10) {
                $('input:text').val(num + 1);
            }
            if (num > 0) {
                $('.button-count:first-child').prop('disabled', false);
            }
            if (num == 9) {
                $('.button-count:last-child').prop('disabled', true);
            }
            });

            $(".back").click(function(){
            $("body").fadeOut(1000, function(){
                window.location.href = "http://localhost/roma/products.php";
            });
           
            

	  });
      $("#addbutton").click(function(){
            $button = $('.addbutton').val();
            $nb = $('#nbpro').val();
            $("body").fadeOut(1000, function(){
                window.location.href = "http://localhost/roma/panel.php?id="+$button+"&nb="+$nb;
            });
           
            

	  });

      $("#signbutton").click(function(){
            
            $("body").fadeOut(1000, function(){
                window.location.href = "http://localhost/roma/signin.php";
            });
           
            

	  });


     

    </script>
</body>
</html>